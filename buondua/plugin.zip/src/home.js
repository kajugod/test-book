function execute() {
    return Response.success([
        {title: "Hot", input: "https://xiutaku.com/hot/", script: "gen.js"}
    ]);
}