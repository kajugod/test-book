function execute() {
    return Response.success([
        {title: "Top 3", input: "https://misskon.com/top3/", script: "gen.js"}
    ]);
}