function execute() {
    return Response.success([
        {title: "buon dua", input: "https://misskon.com/top3/", script: "gen.js"},
    ]);
}