function execute() {
    return Response.success([
        {title: "Hot", input: "https://cosplaytele.com/", script: "gen.js"}
 
    ]);
}