function execute() {
    return Response.success([
        {title: "Ranking", input: "https://hentai-img.com/ranking/", script: "gen.js"}

    ]);
}