function execute() {
    return Response.success([
        {title: "Home", input: "https://porn-images-xxx.com/recently/", script: "gen.js"},
        {title: "Ranking", input: "https://porn-images-xxx.com/ranking/", script: "gen.js"},
        {title: "Ranking Image", input: "https://porn-images-xxx.com/ranking-images/", script: "gen.js"},
        {title: "AI Generated", input: "https://porn-images-xxx.com/search/keyword/AI+Generated/", script: "gen.js"},
        {title: "Uncensored", input: "https://porn-images-xxx.com/search/tag/uncensored/", script: "gen.js"},
        {title: "Fukuda Eimi", input: "https://porn-images-xxx.com/search/keyword/fukuda+eimi/page/1/", script: "gen.js"},      
        {title: "AV", input: "https://porn-images-xxx.com/search/tag/av-actress-images/", script: "gen.js"}
        
    ]);
}