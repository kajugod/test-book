function execute() {
    return Response.success([
        {title: "Hot", input: "https://kiutaku.com/hot/", script: "gen.js"},
        {title: "Byoru", input: "https://kiutaku.com/tag/516", script: "gen.js"},
        {title: "Sayo Momo", input: "https://kiutaku.com/tag/990", script: "gen.js"},
        {title: "aYa Huang", input: "https://kiutaku.com/tag/359", script: "gen.js"},
        {title: "Aqua 水淼", input: "https://kiutaku.com/tag/494", script: "gen.js"},
        {title: "Umeko J", input: "https://kiutaku.com/tag/677", script: "gen.js"},
        {title: "Chunmomo", input: "https://kiutaku.com/tag/574", script: "gen.js"},
        {title: "NinJa 阿寨寨", input: "https://kiutaku.com/tag/639", script: "gen.js"},
        {title: "Hana Bunny", input: "https://kiutaku.com/tag/59", script: "gen.js"},
        {title: "Meenfox", input: "https://kiutaku.com/tag/860", script: "gen.js"},
        {title: "Potato Godzilla", input: "https://kiutaku.com/tag/77", script: "gen.js"},
        {title: "Queenie Chuppy", input: "https://kiutaku.com/tag/313", script: "gen.js"}
 
    ]);
}