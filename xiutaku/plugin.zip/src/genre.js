function execute() {
    return Response.success([
        {title: "xiutaku", input: "https://xiutaku.com/hot/", script: "gen.js"},
    ]);
}