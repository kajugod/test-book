function execute() {
    return Response.success([
        {title: "杨晨晨", input: "https://xiutaku.com/girl/290", script: "gen.js"},
        {title: "周于希", input: "https://xiutaku.com/girl/322", script: "gen.js"},
        {title: "朱可儿", input: "https://xiutaku.com/girl/585", script: "gen.js"},
        {title: "王雨纯", input: "https://xiutaku.com/girl/435", script: "gen.js"},
        {title: "尤妮丝", input: "https://xiutaku.com/girl/468", script: "gen.js"},   
        {title: "刘钰儿", input: "https://xiutaku.com/girl/298", script: "gen.js"},
        {title: "美七", input: "https://xiutaku.com/girl/700", script: "gen.js"},
        {title: "心妍小公主", input: "https://xiutaku.com/girl/479", script: "gen.js"},       
        {title: "小蛮妖", input: "https://xiutaku.com/girl/566", script: "gen.js"},
        {title: "唐宁宁", input: "https://xiutaku.com/girl/1570", script: "gen.js"},
        {title: "小薯条", input: "https://xiutaku.com/girl/1589", script: "gen.js"},
        {title: "幼幼", input: "https://xiutaku.com/girl/1540", script: "gen.js"},

        {title: "XiuRen", input: "https://xiutaku.com/brand/1", script: "gen.js"},
        {title: "XiaoYu", input: "https://xiutaku.com/brand/23", script: "gen.js"},
        {title: "BoLoli", input: "https://xiutaku.com/brand/6", script: "gen.js"},
        {title: "DKGirl", input: "https://xiutaku.com/brand/15", script: "gen.js"},
        {title: "YouMi", input: "https://xiutaku.com/brand/17", script: "gen.js"},
        {title: "Micat", input: "https://xiutaku.com/brand/20", script: "gen.js"},
        {title: "Imiss", input: "https://xiutaku.com/brand/5", script: "gen.js"},
        {title: "MyGirl", input: "https://xiutaku.com/brand/4", script: "gen.js"},
        {title: "HuaYan", input: "https://xiutaku.com/brand/14", script: "gen.js"},
        {title: "MFStar", input: "https://xiutaku.com/brand/2", script: "gen.js"},
        {title: "HuaYang花漾", input: "https://xiutaku.com/brand/21", script: "gen.js"},
        {title: "FeiLin", input: "https://xiutaku.com/brand/10", script: "gen.js"},
        {title: "MiStar", input: "https://xiutaku.com/brand/3", script: "gen.js"},
        {title: "HXingYan", input: "https://xiutaku.com/brand/22", script: "gen.js"},
        {title: "MiiTao", input: "https://xiutaku.com/brand/9", script: "gen.js"}
    ]);
}