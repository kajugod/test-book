function execute() {
    return Response.success([
        {title: "Hot", input: "https://xiutaku.com/hot/", script: "gen.js"},
        {title: "妲己_Toxic", input: "https://xiutaku.com/girl/267", script: "gen.js"},
        {title: "允爾", input: "https://xiutaku.com/girl/642", script: "gen.js"},
        {title: "温心怡", input: "https://xiutaku.com/girl/450", script: "gen.js"},
        {title: "果儿", input: "https://xiutaku.com/girl/409", script: "gen.js"},
        {title: "奶瓶土肥圆", input: "https://xiutaku.com/girl/474", script: "gen.js"},
        {title: "小海臀", input: "https://xiutaku.com/girl/766", script: "gen.js"},
        {title: "田冰冰", input: "https://xiutaku.com/girl/638", script: "gen.js"},
        {title: "周妍希", input: "https://xiutaku.com/girl/1504", script: "gen.js"},
        {title: "玥儿玥", input: "https://xiutaku.com/girl/647", script: "gen.js"},
        {title: "芝芝Booty", input: "https://xiutaku.com/girl/478", script: "gen.js"},
    ]);
}