function execute() {
    return Response.success([
        {title: "Hot", input: "https://8kcosplay.com/", script: "gen.js"}
 
    ]);
}