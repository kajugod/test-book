function execute() {
    return Response.success([
        {title: "小恩", input: "https://buondua.com/tag/小恩-11611", script: "gen.js"},
        {title: "水淼Aqua", input: "https://buondua.com/tag/水淼aqua-10796", script: "gen.js"},
        {title: "布丁大法", input: "https://buondua.com/tag/布丁大法-11518", script: "gen.js"},
        {title: "Egg_尤妮丝", input: "https://buondua.com/tag/egg_尤妮丝-10401", script: "gen.js"},
        {title: "Hani", input: "https://buondua.com/tag/hani-11379", script: "gen.js"},
        {title: "Arty亞緹", input: "https://buondua.com/tag/arty亞緹-11576", script: "gen.js"},
        {title: "Hana Bunny", input: "https://buondua.com/tag/hana-bunny-10928", script: "gen.js"},
        {title: "Byoru", input: "https://buondua.com/tag/byoru-10931", script: "gen.js"},
        {title: "Zhu Ke Er", input: "https://buondua.com/tag/zhu-ke-er-9475", script: "gen.js"},
        {title: "rioko凉凉子", input: "https://buondua.com/tag/rioko凉凉子-10567", script: "gen.js"},
        {title: "小丁", input: "https://buondua.com/tag/小丁-11559", script: "gen.js"},
        {title: "Woo U", input: "https://buondua.com/tag/woo-u-11451", script: "gen.js"}

    ]);
}