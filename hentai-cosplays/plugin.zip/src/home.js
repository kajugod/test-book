function execute() {
    return Response.success([
        {title: "Home", input: "https://hentai-cosplays.com/", script: "gen.js"},
        {title: "Ranking", input: "https://hentai-cosplays.com/ranking/", script: "gen.js"},
        {title: "Ranking Image", input: "https://hentai-cosplays.com/ranking-images/", script: "gen.js"},
        {title: "Naji Adult", input: "https://hentai-cosplays.com/search/keyword/Naji+Adult/page/1/", script: "gen.js"},
        {title: "Archive", input: "https://hentai-cosplays.com/archive/", script: "gen.js"},
        {title: "Minichu", input: "https://hentai-cosplays.com/search/keyword/Minichu/", script: "gen.js"},      
        {title: "Son Ye-Eun", input: "https://hentai-cosplays.com/search/keyword/Son%20Ye-Eun/", script: "gen.js"},
        {title: "水淼Aqua", input: "https://hentai-cosplays.com/search/keyword/%E6%B0%B4%E6%B7%BCAqua/page/1/", script: "gen.js"},
        {title: "喵小吉", input: "https://hentai-cosplays.com/search/keyword/%E5%96%B5%E5%B0%8F%E5%90%89/", script: "gen.js"},
        {title: "Umeko J", input: "https://hentai-cosplays.com/search/keyword/Umeko+J/", script: "gen.js"},
        {title: "Byoru", input: "https://hentai-cosplays.com/search/keyword/Byoru/", script: "gen.js"},
        {title: "Neppu", input: "https://hentai-cosplays.com/search/keyword/Neppu/", script: "gen.js"},
        {title: "Ninja 阿寨寨", input: "https://hentai-cosplays.com/search/keyword/%E9%98%BF%E5%AF%A8%E5%AF%A8/", script: "gen.js"},
        {title: "Potato Godzilla", input: "https://hentai-cosplays.com/search/keyword/Potato+Godzilla/", script: "gen.js"},
        {title: "Xenon", input: "https://hentai-cosplays.com/search/keyword/Xenon/", script: "gen.js"},
        {title: "Arty Huang", input: "https://hentai-cosplays.com/search/keyword/arty/page/1/", script: "gen.js"},
        {title: "Rinka", input: "https://hentai-cosplays.com/search/keyword/rinka/", script: "gen.js"},
        {title: "Rioko", input: "https://hentai-cosplays.com/search/keyword/%E5%87%89%E5%87%89%E5%AD%90/", script: "gen.js"},
        {title: "Hane Ame", input: "https://hentai-cosplays.com/search/keyword/Hane+Ame/", script: "gen.js"},
        {title: "Hidori Eose", input: "https://hentai-cosplays.com/search/keyword/Hidori+Rose/", script: "gen.js"},
        {title: "Kalinka Fox", input: "https://hentai-cosplays.com/search/keyword/Kalinka/", script: "gen.js"},
        {title: "Yeon Woo 연우", input: "https://hentai-cosplays.com/search/keyword/%EC%97%B0%EC%9A%B0/page/1/", script: "gen.js"},
        {title: "Korea", input: "https://hentai-cosplays.com/search/tag/korea/", script: "gen.js"},
        {title: "Destiny", input: "https://hentai-cosplays.com/search/keyword/Destiny/page/1/", script: "gen.js"},
        {title: "Neppu", input: "https://hentai-cosplays.com/search/keyword/Neppu/", script: "gen.js"},
        {title: "Neppu", input: "https://hentai-cosplays.com/search/keyword/Neppu/", script: "gen.js"}

    ]);
}