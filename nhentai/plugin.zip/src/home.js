function execute() {
    return Response.success([
        {title: "New uploads", input: "https://nhentai.to", script: "gen.js"}
    ]);
}