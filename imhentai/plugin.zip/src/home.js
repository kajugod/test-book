function execute() {
    return Response.success([
        {title: "New uploads", input: "https://imhentai.xxx", script: "gen.js"}
    ]);
}