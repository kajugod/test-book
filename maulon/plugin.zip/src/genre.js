function execute() {
    return Response.success([
        {title: "Hot", input: "https://7sex.maulon.pro/", script: "gen.js"}
 


        
    ]);
}